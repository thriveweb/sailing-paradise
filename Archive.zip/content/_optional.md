---
optional: hello gatsby
title: ''
subtitle: ''
featuredImage: /images/logo.svg
services:
  - serviceContent:
     icon: /images/logo.svg
     title: ''
     description: ''
     buttonUrl: ''
highlights:
  - icon: /images/logo.svg
  - title: ''
serviceBanner:
  buttonTitle: ''
  buttonUrl: ''
  featuredImage: /images/logo.svg
  subtitle: ''
  title: ''

---

<!--Use this to force Gatsby to deal with optional images-->
