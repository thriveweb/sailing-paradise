---
template: SingleCaseStudy
name: Tahlia
title: Birthday Party
date: '2018-09-13'
featuredImage: /images/uploads/dsc_0250_2.jpg
videoSection:
  imageOverlay: ''
  title: ''
  video: ''
secondaryImage: /images/uploads/DSC_0038.jpg
excerpt: >-
  Tahlia - The whole day was amazing. The staff were absolutely exceptional and
  made my mum's birthday run so smoothly, they both had professional yet very
  warm & calming attitudes. And every single person who came has commented on
  how fantastic they were.   
gallery:
  - image: /images/uploads/dsc_0169_2.jpg
  - image: /images/uploads/dsc_0169_2.jpg
  - image: /images/uploads/dsc_0502_1.jpg
  - image: /images/uploads/dsc_0359_2.jpg
  - {}
secondaryBanner:
  buttonTitle: Back
  buttonUrl: case-studies
  title: back to all happy sailors
  featuredImage: /images/uploads/boat-img10.jpg
---
Tahlia organised a beautiful afternoon on the Broadwater with family to celebrate a very special family birthday!   With littlies on board the whole family enjoyed a swim stop at Wavebreak Island with Stand Up Paddleboarding and Sand Castle Building the highlights...   A special mention must go to the beautiful birthday cake hand baked by Tahlia - wow!   Happy birthday Leigh!
