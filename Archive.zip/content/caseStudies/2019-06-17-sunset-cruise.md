---
template: SingleCaseStudy
name: 'Sean Gilliland, Australia'
title: Sunset Cruise
date: '2019-03-31'
featuredImage: /images/uploads/BDAY People 11 070718b.JPG
excerpt: >-
  To celebrate my fathers 70th Birthday I wanted to do something different and
  Dad loved sailing in his younger years so what better way to celebrate than on
  a catamaran.  Anthony (Skipper), Chanelle and Anna were were just pure class.
  They were incredibly polite and professional and nothing during the cruise was
  too much.  We had a party of 7 which included one child (son) and he was made
  to feel right at home. When it came time to hoist the jib both my father and
  son were asked to assist which made for some great photos which will be
  cherished. I cannot recommend Sailing in Paradise Gold Coast highly enough. If
  we could give them 10 stars we would. Value for money this was bloody
  brilliant.    Tripadvisor
---
Sean arranged for his family of 7 to join our Sunset and City Lights Cruise as a special gift to his father.  We were delighted to help make this a special occasion for the family.  For smaller groups, joining one of our ticketed cruises can be an ideal option to celebrate a special occasion.
