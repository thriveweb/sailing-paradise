---
slug: nav-items
navItems:
  - slug: cruises
    subNavItems:
      - slug: boat-tours/sails-and-sights-cruise/
        title: Sails and Sights Cruise
      - slug: boat-tours/cruise-example-2/
        title: Cruise Example 2
    title: Cruises
  - slug: private-charters
    subNavItems:
      - slug: boat-tours/birthday-parties
        title: Birthday Parties
      - slug: boat-tours/proposals
        title: Proposals
      - slug: boat-tours/hens-parties
        title: Hen's Parties
      - slug: boat-tours/romantic-sails
        title: Romantic Sails
      - slug: boat-tours/corporate-events
        title: Corporate Events
      - slug: boat-tours/family-gatherings
        title: Family Gatherings
      - slug: boat-tours/raft-up-parties
        title: Raft Up Parties
      - slug: boat-tours/memorials
        title: Memorials
      - slug: boat-tours/christmas-parties
        title: Christmas Parties
      - slug: boat-tours/private-charters
        title: Private Charters
      - slug: boat-tours/sightseeing
        title: Sightseeing
      - slug: boat-tours/bucks-parties
        title: Buck's Parties
    title: Private Charters
  - slug: boats
    title: Our Boats
  - slug: about
    title: About Us
  - subNavItems:
      - slug: case-studies
        title: Happy Sailors
      - slug: blog
        title: Latest News
      - slug: contact
        title: Contact Us
    title: More
---
