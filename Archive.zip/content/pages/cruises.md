---
template: Cruises
slug: cruises
title: Cruises
featuredImage: /images/uploads/news-banner.jpg
intro: >-
  ## Gold Coast Sunset Cruise


  ## 3 hour Island Adventure


  ## 2 hour Sails and Sights Cruise


  If you are travelling alone or have a smaller group and don't mind sharing
  your experience with other guests, consider one of our ticketed tour options
  (subject to availability).
---

