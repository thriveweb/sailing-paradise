---
template: SinglePost
title: Example Post 3
status: Featured / Published
date: '2018-03-27'
categories:
  - category: News
featuredImage: /images/uploads/DSC_0038.jpg
excerpt: >-
  Etiam ac quam eget lectus venenatis ullamcorper sit amet non arcu. Nullam
  interdum arcu vitae augue pulvinar sodales. Sed non dui diam. Quisque lectus
  est, lobortis ac efficitur vitae, posuere a mauris. Phasellus ac dui
  pellentesque, lacinia risus ut, imperdiet eros.
meta:
  canonicalLink: ''
  description: ''
  noindex: false
  title: ''
---

Paragraphs are separated by a blank line.

![Test Image](/images/uploads/vyouw5byhlc.jpeg)

The second paragraph. This is placeholder text that our web designers put here to make sure words appear properly on your website. _Italic_, **bold**, and `monospace`.

### Unordered lists:

- this one
- that one
- the other one

### Ordered lists:

1. first item
2. second item
3. third item

> Block quotes are written like so.
>
> They can span multiple paragraphs,
> if you like.

## Heading 2

# Heading 1

## Heading 2

### Heading 3

#### Heading 4

##### Heading 5

Heading 6
